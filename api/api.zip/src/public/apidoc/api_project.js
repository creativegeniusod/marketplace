define({
  "name": "SpurtCommerce V3.0.2",
  "version": "3.0.2",
  "description": "SpurtCommerce RESTFUL API Document",
  "title": "SpurtCommerce RESTFUL API Document",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2022-08-10T04:54:13.366Z",
    "url": "http://apidocjs.com",
    "version": "0.17.7"
  }
});
