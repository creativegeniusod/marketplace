import { Component } from '@angular/core';

@Component({
  selector: 'app-trending-product',
  templateUrl: './trending-product.component.html',
  styleUrls: ['./trending-product.component.scss']
})
// implements OnInit, OnDestroy, AfterViewInit
export class TrendingProductComponent  {
  }
