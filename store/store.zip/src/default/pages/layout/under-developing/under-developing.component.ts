/*
 * spurtcommerce
 * http://www.spurtcommerce.com
 *
 * Copyright (c) 2022 piccosoft ltd
 * Author piccosoft ltd <support@piccosoft.com>
 * Licensed under the MIT license.
 */
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-under-developing',
  templateUrl: './under-developing.component.html',
  styleUrls: ['./under-developing.component.scss']
})
export class UnderDevelopingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
