/*
 * spurtcommerce
 * http://www.spurtcommerce.com
 *
 * Copyright (c) 2022 piccosoft ltd
 * Author piccosoft ltd <support@piccosoft.com>
 * Licensed under the MIT license.
 */
export const environment = {
    production: true,
    storeUrl: '', // <Your API base url>
    imageUrl: '' // <Your API url for image resize>
};
